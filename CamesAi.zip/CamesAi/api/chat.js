// Fungsi serverless Vercel. Hanya melayani user yang sudah login Firebase.
// Kunci API hanya dibaca dari Environment Variables, tidak pernah dari kode.
// Urutan penyedia: Gemini -> Groq -> OpenRouter (tiap penyedia memutar beberapa key).
// Jawaban dikirim sebagai teks yang mengalir (streaming) bila penyedianya mendukung.
import { createRemoteJWKSet, jwtVerify } from 'jose';

export const config = { maxDuration: 60 };

const PROJECT = process.env.FIREBASE_PROJECT_ID || 'camesawesome';
const JWKS = createRemoteJWKSet(
  new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com')
);

const COOL = {};
const RR = {};
const HITS = new Map();
const MAX_PER_MIN = 20; // batas pesan per user per menit
const MAX_IMG_TOTAL = 3_600_000; // karakter base64; batas body Vercel 4,5 MB
const MIME_OK = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

async function verify(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, JWKS, {
      issuer: `https://securetoken.google.com/${PROJECT}`,
      audience: PROJECT,
    });
    return payload.sub || null;
  } catch {
    return null;
  }
}

function limited(uid) {
  const now = Date.now();
  const arr = (HITS.get(uid) || []).filter((t) => now - t < 60_000);
  if (arr.length >= MAX_PER_MIN) {
    HITS.set(uid, arr);
    return true;
  }
  arr.push(now);
  HITS.set(uid, arr);
  return false;
}

function keys(prefix) {
  const out = [];
  for (let i = 1; i <= 10; i++) {
    const k = process.env[`${prefix}_${i}`];
    if (k && k.trim()) out.push(k.trim());
  }
  return out;
}

function rotate(arr, provider) {
  if (arr.length < 2) return arr;
  const n = (RR[provider] = ((RR[provider] ?? -1) + 1) % arr.length);
  return [...arr.slice(n), ...arr.slice(0, n)];
}

function cooldownFor(e) {
  const m = String(e.message || '').toLowerCase();
  if (e.status === 429 || m.includes('quota') || m.includes('resource_exhausted')) return 60_000;
  if (e.status === 401 || e.status === 403 || e.status === 404 || m.includes('api key not valid') || m.includes('api_key_invalid')) return 600_000;
  if ((e.status || 0) >= 500 || m.includes('overloaded') || m.includes('unavailable')) return 15_000;
  return 5_000;
}

function normalize(messages) {
  return (Array.isArray(messages) ? messages : [])
    .filter((m) => m && typeof m.content === 'string' && m.content.trim())
    .slice(-30)
    .map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content.slice(0, 12000) }));
}

function cleanImages(images) {
  if (!Array.isArray(images)) return [];
  const out = [];
  let total = 0;
  for (const im of images.slice(0, 6)) {
    if (!im || !MIME_OK.has(im.mime) || typeof im.data !== 'string' || !/^[A-Za-z0-9+/]+=*$/.test(im.data)) continue;
    total += im.data.length;
    if (total > MAX_IMG_TOTAL) break;
    out.push({ mime: im.mime, data: im.data });
  }
  return out;
}

/* ---------- Gemini (streaming) ---------- */
function toContents(messages, images) {
  const contents = [];
  for (const m of messages) {
    const role = m.role === 'assistant' ? 'model' : 'user';
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts[0].text += '\n\n' + m.content;
    else contents.push({ role, parts: [{ text: m.content }] });
  }
  while (contents.length && contents[0].role !== 'user') contents.shift();
  if (!contents.length) throw new Error('Pesan kosong');
  const lastUser = contents[contents.length - 1];
  if (images.length && lastUser.role === 'user') {
    lastUser.parts.unshift(...images.map((im) => ({ inline_data: { mime_type: im.mime, data: im.data } })));
  }
  return contents;
}

function startText(res) {
  res.status(200);
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('X-Accel-Buffering', 'no');
}

async function streamGemini(key, model, messages, images, res) {
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({
        contents: toContents(messages, images),
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 },
      }),
    }
  );
  if (!r.ok) {
    const t = await r.text().catch(() => '');
    const err = new Error(`HTTP ${r.status}: ${t.slice(0, 200)}`);
    err.status = r.status;
    throw err;
  }
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  let started = false;
  const emit = (t) => {
    if (!t) return;
    if (!started) {
      started = true;
      startText(res);
    }
    res.write(t);
  };
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (!line.startsWith('data:')) continue;
        const js = line.slice(5).trim();
        if (!js || js === '[DONE]') continue;
        let d;
        try {
          d = JSON.parse(js);
        } catch {
          continue;
        }
        emit((d?.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join(''));
      }
    }
  } catch (e) {
    if (!started) throw e;
    res.write('\n\n[Jawaban terputus]');
  }
  if (!started) throw new Error('Respons kosong dari Gemini');
  res.end();
}

/* ---------- Groq & OpenRouter (sekali kirim) ---------- */
function withImages(messages, images) {
  const out = messages.map((m) => ({ ...m }));
  const last = out[out.length - 1];
  if (last && last.role === 'user') {
    last.content = [
      ...images.map((im) => ({ type: 'image_url', image_url: { url: `data:${im.mime};base64,${im.data}` } })),
      { type: 'text', text: last.content },
    ];
  }
  return out;
}

async function callOpenAICompat(url, key, model, messages, headers = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}`, ...headers },
    body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 2048 }),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    const err = new Error(`HTTP ${res.status}: ${t.slice(0, 200)}`);
    err.status = res.status;
    throw err;
  }
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content || '';
  if (!text.trim()) throw new Error('Respons kosong dari AI');
  return text;
}

/* ---------- Pemilihan penyedia ---------- */
function buildTargets(smart, hasImages) {
  const gemini = smart
    ? process.env.GEMINI_MODEL_SMART || 'gemini-3.6-flash'
    : process.env.GEMINI_MODEL_FAST || 'gemini-3.5-flash-lite';
  const groq = smart
    ? process.env.GROQ_MODEL_SMART || 'llama-3.3-70b-versatile'
    : process.env.GROQ_MODEL_FAST || 'llama-3.1-8b-instant';
  const orText = process.env.OPENROUTER_MODEL || 'meta-llama/llama-3.3-70b-instruct:free';
  const orVision = process.env.OPENROUTER_VISION_MODEL || 'google/gemma-3-27b-it:free';

  const t = [];
  rotate(keys('GEMINI_KEY'), 'gemini').forEach((key) => t.push({ kind: 'gemini', key, model: gemini }));
  if (!hasImages) rotate(keys('GROQ_KEY'), 'groq').forEach((key) => t.push({ kind: 'groq', key, model: groq }));
  rotate(keys('OPENROUTER_KEY'), 'openrouter').forEach((key) =>
    t.push({ kind: 'openrouter', key, model: hasImages ? orVision : orText })
  );
  return t.map((x) => ({ ...x, id: `${x.kind}:${x.key}` }));
}

async function respond(res, messages, smart, images) {
  const targets = buildTargets(smart, images.length > 0);
  if (targets.length === 0) throw new Error('Belum ada API key di Vercel (GEMINI_KEY_1 / GROQ_KEY_1 / OPENROUTER_KEY_1).');
  const now = Date.now();
  const ready = targets.filter((t) => (COOL[t.id] || 0) <= now);
  let last = '';
  for (const t of ready) {
    try {
      if (t.kind === 'gemini') {
        await streamGemini(t.key, t.model, messages, images, res);
        return;
      }
      const text =
        t.kind === 'groq'
          ? await callOpenAICompat('https://api.groq.com/openai/v1/chat/completions', t.key, t.model, messages)
          : await callOpenAICompat(
              'https://openrouter.ai/api/v1/chat/completions',
              t.key,
              t.model,
              images.length ? withImages(messages, images) : messages,
              { 'HTTP-Referer': 'https://cames.my.id', 'X-Title': 'CamesAi' }
            );
      startText(res);
      res.end(text);
      return;
    } catch (e) {
      last = `${t.kind}: ${e.message}`;
      COOL[t.id] = Date.now() + cooldownFor(e);
    }
  }
  if (ready.length === 0) throw new Error('Semua API key sedang kena limit. Tunggu sebentar lalu coba lagi.');
  throw new Error(`AI gagal. ${last}`);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const uid = await verify(req);
  if (!uid) return res.status(401).json({ error: 'Silakan login dulu.' });
  if (limited(uid)) return res.status(429).json({ error: 'Terlalu cepat. Tunggu sebentar lalu coba lagi.' });
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const messages = normalize(body.messages);
    if (messages.length === 0) return res.status(400).json({ error: 'Pesan kosong' });
    await respond(res, messages, body.tier !== 'quick', cleanImages(body.images));
  } catch (e) {
    if (!res.headersSent) return res.status(502).json({ error: e.message || 'Gagal memproses permintaan' });
    try { res.end(); } catch { /* sudah selesai */ }
  }
}
